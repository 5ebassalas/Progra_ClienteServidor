package fideflix;

// Subclase de Audiovisual que representa un documental
public class Documental extends Audiovisual {

    private String tema; // Tema principal del documental

    public Documental(String titulo, int duracionEnMinutos, String genero, String clasificacionEdad, String tema) {
        super(titulo, duracionEnMinutos, genero, clasificacionEdad); // Llama al constructor de Audiovisual
        this.tema = tema;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }
}
