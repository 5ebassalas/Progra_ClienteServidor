package fideflix;

// Clase principal para probar la instanciacion de objetos y la herencia
public class Main {

    public static void main(String[] args) {

        // Se crean los objetos de cada tipo de contenido audiovisual
        Pelicula pelicula1 = new Pelicula("Interstellar", 169, "Ciencia Ficcion", "PG-13", "Christopher Nolan");
        Serie serie1 = new Serie("Breaking Bad", 50, "Drama", "TV-MA", 5);
        Documental documental1 = new Documental("Planet Earth", 90, "Naturaleza", "TV-G", "Vida silvestre");

        // Se crea un objeto Usuario
        Usuario usuario1 = new Usuario("carlos_mora", "carlos@fideflix.com", "abc123");

        // Se imprimen los titulos para verificar que se crearon correctamente
        System.out.println("Pelicula: " + pelicula1.getTitulo());
        System.out.println("Serie: " + serie1.getTitulo());
        System.out.println("Documental: " + documental1.getTitulo());

        // Se ejecuta el metodo estatico de inicio de sesion
        Usuario.iniciarSesion(usuario1);
    }
}
