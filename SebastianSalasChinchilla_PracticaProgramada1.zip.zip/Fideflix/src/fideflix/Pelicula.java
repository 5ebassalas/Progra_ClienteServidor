package fideflix;

// Subclase de Audiovisual que representa una pelicula
public class Pelicula extends Audiovisual {

    private String director; // Atributo propio de Pelicula

    public Pelicula(String titulo, int duracionEnMinutos, String genero, String clasificacionEdad, String director) {
        super(titulo, duracionEnMinutos, genero, clasificacionEdad); // Llama al constructor de Audiovisual
        this.director = director;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }
}
