package fideflix;

// Subclase de Audiovisual que representa una serie de television
public class Serie extends Audiovisual {

    private int numeroTemporadas; // Cantidad de temporadas de la serie

    public Serie(String titulo, int duracionEnMinutos, String genero, String clasificacionEdad, int numeroTemporadas) {
        super(titulo, duracionEnMinutos, genero, clasificacionEdad); // Llama al constructor de Audiovisual
        this.numeroTemporadas = numeroTemporadas;
    }

    public int getNumeroTemporadas() {
        return numeroTemporadas;
    }

    public void setNumeroTemporadas(int numeroTemporadas) {
        this.numeroTemporadas = numeroTemporadas;
    }
}
