package fideflix;

// Clase que representa a un usuario de la plataforma Fideflix
public class Usuario {

    private String nombreUsuario;
    private String correo;
    private String contrasena;

    public Usuario(String nombreUsuario, String correo, String contrasena) {
        this.nombreUsuario = nombreUsuario;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    // Metodo estatico que simula el inicio de sesion e imprime un saludo
    public static void iniciarSesion(Usuario usuario) {
        System.out.println("¡Bienvenido " + usuario.getNombreUsuario() + "!");
    }
}
