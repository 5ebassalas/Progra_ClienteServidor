package fideflix;

// Subclase de Audiovisual que representa un documental
public class Documental extends Audiovisual implements Comparable<Documental> {

    private String tema; // Tema principal del documental

    public Documental(String titulo, int duracionEnMinutos, String genero, String clasificacionEdad, String tema) {
        super(titulo, duracionEnMinutos, genero, clasificacionEdad); // Llama al constructor de Audiovisual
        this.tema = tema;
    }

    public String getTema() {
        return tema;
    }

    public void setTema(String tema) {
        this.tema = tema;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("[Documental] " + getTitulo() + " | Tema: " + tema
                + " | " + getDuracionEnMinutos() + " min | Genero: " + getGenero()
                + " | Clasificacion: " + getClasificacionEdad());
    }

    // Los documentales se ordenan alfabeticamente por titulo
    @Override
    public int compareTo(Documental otro) {
        return this.getTitulo().compareToIgnoreCase(otro.getTitulo());
    }

    @Override
    public String toString() {
        return getTitulo();
    }
}
