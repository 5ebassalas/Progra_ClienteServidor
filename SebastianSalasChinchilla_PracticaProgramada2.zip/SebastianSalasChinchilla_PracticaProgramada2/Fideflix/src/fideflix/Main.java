package fideflix;

import java.util.ArrayList;
import java.util.Collections;

// Clase principal que demuestra colecciones, excepciones propias, sort y polimorfismo
public class Main {

    // Elimina un usuario de la lista. Si no esta, lanza la excepcion propia.
    // remove(Object) devuelve false cuando no encontro el elemento.
    public static void eliminarUsuario(ArrayList<Usuario> lista, Usuario usuario) throws UsuarioNoExisteException {
        boolean eliminado = lista.remove(usuario);
        if (!eliminado) {
            throw new UsuarioNoExisteException("El usuario '" + usuario.getNombreUsuario()
                    + "' no existe en la coleccion.");
        }
        System.out.println("Usuario eliminado: " + usuario.getNombreUsuario());
    }

    public static void imprimirUsuarios(ArrayList<Usuario> lista) {
        for (Usuario u : lista) {
            System.out.println("  - " + u);
        }
    }

    public static void main(String[] args) {

        // ===== 1. Coleccion de usuarios (10 usuarios distintos) =====
        System.out.println("===== 1. CREACION DE USUARIOS =====");
        ArrayList<Usuario> usuarios = new ArrayList<>();
        usuarios.add(new Usuario("carlos_mora", "carlos.mora@fideflix.com", "abc123"));
        usuarios.add(new Usuario("sofia_vargas", "sofia.vargas@fideflix.com", "sofi2024"));
        usuarios.add(new Usuario("andres_jimenez", "andres.jimenez@fideflix.com", "andres#77"));
        usuarios.add(new Usuario("maria_rodriguez", "maria.rodriguez@fideflix.com", "mari_pass"));
        usuarios.add(new Usuario("diego_chaves", "diego.chaves@fideflix.com", "d1eg0cr"));
        usuarios.add(new Usuario("valeria_solano", "valeria.solano@fideflix.com", "vale456"));
        usuarios.add(new Usuario("jose_alvarado", "jose.alvarado@fideflix.com", "josepura"));
        usuarios.add(new Usuario("daniela_quesada", "daniela.quesada@fideflix.com", "dani_q90"));
        usuarios.add(new Usuario("esteban_araya", "esteban.araya@fideflix.com", "este2025"));
        usuarios.add(new Usuario("gabriela_umana", "gabriela.umana@fideflix.com", "gabi_cr"));
        usuarios.add(new Usuario("luis_camacho", "luis.camacho@fideflix.com", "luis!321"));
        System.out.println("Usuarios registrados: " + usuarios.size());
        imprimirUsuarios(usuarios);

        // Se prueba el metodo estatico de la Practica 1
        System.out.println();
        Usuario.iniciarSesion(usuarios.get(0));

        // ===== 2. Eliminar usuarios (caso exitoso y caso con excepcion) =====
        System.out.println();
        System.out.println("===== 2. ELIMINAR USUARIOS (remove + excepcion propia) =====");

        // Caso 1: el usuario SI existe. Es un objeto nuevo, pero equals lo reconoce por el nombre.
        Usuario usuarioExistente = new Usuario("diego_chaves", "diego.chaves@fideflix.com", "d1eg0cr");
        try {
            eliminarUsuario(usuarios, usuarioExistente);
        } catch (UsuarioNoExisteException e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Caso 2: el usuario NO existe, se lanza UsuarioNoExisteException
        Usuario usuarioInexistente = new Usuario("pedro_fantasma", "pedro@fideflix.com", "0000");
        try {
            eliminarUsuario(usuarios, usuarioInexistente);
        } catch (UsuarioNoExisteException e) {
            System.out.println("Error: " + e.getMessage());
        }
        System.out.println("Usuarios restantes: " + usuarios.size());

        // ===== 3. Ordenar usuarios con sort =====
        System.out.println();
        System.out.println("===== 3. ORDENAR USUARIOS (sort) =====");
        System.out.println("Antes de ordenar:");
        imprimirUsuarios(usuarios);

        Collections.sort(usuarios); // usa el compareTo de Usuario

        System.out.println("Despues de ordenar (por nombre de usuario):");
        imprimirUsuarios(usuarios);

        // ===== 4. Comparable en Pelicula, Serie y Documental =====
        System.out.println();
        System.out.println("===== 4. COLECCIONES ORDENADAS DE PELICULA, SERIE Y DOCUMENTAL =====");
        ArrayList<Pelicula> peliculas = new ArrayList<>();
        peliculas.add(new Pelicula("Interstellar", 169, "Ciencia Ficcion", "PG-13", "Christopher Nolan"));
        peliculas.add(new Pelicula("Coco", 105, "Animacion", "PG", "Lee Unkrich"));
        peliculas.add(new Pelicula("Parasite", 132, "Suspenso", "R", "Bong Joon-ho"));

        ArrayList<Serie> series = new ArrayList<>();
        series.add(new Serie("Breaking Bad", 50, "Drama", "TV-MA", 5));
        series.add(new Serie("Dark", 55, "Ciencia Ficcion", "TV-MA", 3));
        series.add(new Serie("Avatar: La Leyenda de Aang", 23, "Animacion", "TV-Y7", 3));

        ArrayList<Documental> documentales = new ArrayList<>();
        documentales.add(new Documental("Planet Earth", 90, "Naturaleza", "TV-G", "Vida silvestre"));
        documentales.add(new Documental("Cosmos", 60, "Ciencia", "TV-PG", "El universo"));
        documentales.add(new Documental("Our Planet", 50, "Naturaleza", "TV-G", "Cambio climatico"));

        System.out.println("Peliculas antes de ordenar:    " + peliculas);
        Collections.sort(peliculas);
        System.out.println("Peliculas despues de ordenar:  " + peliculas);

        System.out.println("Series antes de ordenar:       " + series);
        Collections.sort(series);
        System.out.println("Series despues de ordenar:     " + series);

        System.out.println("Documentales antes de ordenar: " + documentales);
        Collections.sort(documentales);
        System.out.println("Documentales despues:          " + documentales);

        // ===== 5. Polimorfismo =====
        System.out.println();
        System.out.println("===== 5. POLIMORFISMO CON AUDIOVISUAL =====");
        // La lista es de tipo Audiovisual, pero guarda objetos de las tres subclases
        ArrayList<Audiovisual> catalogo = new ArrayList<>();
        catalogo.add(peliculas.get(0));
        catalogo.add(series.get(0));
        catalogo.add(documentales.get(0));
        catalogo.add(new Pelicula("Spider-Man: Into the Spider-Verse", 117, "Animacion", "PG", "Peter Ramsey"));
        catalogo.add(new Serie("Stranger Things", 51, "Ciencia Ficcion", "TV-14", 4));
        catalogo.add(new Documental("Free Solo", 100, "Aventura", "PG-13", "Escalada sin cuerdas"));

        // En cada vuelta se ejecuta la version de mostrarInformacion() de la clase real del objeto
        for (Audiovisual contenido : catalogo) {
            contenido.mostrarInformacion();
        }

        // ===== 6. Comentarios de los usuarios =====
        System.out.println();
        System.out.println("===== 6. COMENTARIOS (metodo estatico agregarComentario) =====");
        Audiovisual.agregarComentario("Interstellar: la banda sonora de Hans Zimmer es increible.");
        Audiovisual.agregarComentario("Breaking Bad: la mejor serie que he visto, el final es perfecto.");
        Audiovisual.agregarComentario("Planet Earth: las imagenes de la naturaleza son espectaculares.");
        Audiovisual.agregarComentario("Coco: me hizo llorar, muy buena para ver en familia.");

        int numero = 1;
        for (String comentario : Audiovisual.getComentarios()) {
            System.out.println("  " + numero + ". " + comentario);
            numero++;
        }

        // ===== 7. Destruccion de objetos =====
        System.out.println();
        System.out.println("===== 7. DESTRUCCION DE OBJETOS =====");
        // En Java no existe un "destructor" como en C++: la memoria la libera el
        // recolector de basura (Garbage Collector) cuando un objeto ya no tiene
        // referencias. Lo que hacemos es limpiar las colecciones y poner las
        // referencias en null para que los objetos sean elegibles para recoleccion.
        // System.gc() solo sugiere a la JVM que corra el recolector; no lo garantiza.
        usuarios.clear();
        peliculas.clear();
        series.clear();
        documentales.clear();
        catalogo.clear();
        Audiovisual.getComentarios().clear();

        usuarioExistente = null;
        usuarioInexistente = null;
        usuarios = null;
        peliculas = null;
        series = null;
        documentales = null;
        catalogo = null;

        System.gc();
        System.out.println("Colecciones limpiadas, referencias en null y recolector de basura solicitado.");
        System.out.println("Fin del programa.");
    }
}
