package fideflix;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

// Clase auxiliar: concentra la lectura y escritura del archivo de usuarios
// para que las ventanas no tengan que manejar los streams directamente.
public class GestorUsuarios {

    // Archivo donde se guarda la coleccion. Es una ruta relativa: se crea en la
    // carpeta desde donde se ejecuta el programa (en NetBeans, la carpeta del proyecto).
    public static final String ARCHIVO = "usuarios.dat";

    // Lee la coleccion de usuarios del archivo (deserializacion).
    // Si el archivo todavia no existe (o esta vacio), devuelve una coleccion vacia.
    @SuppressWarnings("unchecked") // readObject devuelve Object; sabemos que se guardo un ArrayList<Usuario>
    public static ArrayList<Usuario> cargarUsuarios() throws IOException, ClassNotFoundException {
        File archivo = new File(ARCHIVO);
        if (!archivo.exists() || archivo.length() == 0) {
            return new ArrayList<>();
        }
        // try-with-resources: el stream se cierra solo al terminar el bloque
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(archivo))) {
            return (ArrayList<Usuario>) entrada.readObject();
        }
    }

    // Guarda la coleccion completa en el archivo (serializacion).
    // Cada vez que se guarda, el archivo se reescribe con todos los usuarios.
    public static void guardarUsuarios(ArrayList<Usuario> usuarios) throws IOException {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(ARCHIVO))) {
            salida.writeObject(usuarios);
        }
    }

    // Indica si ya hay un usuario con ese nombre (sin distinguir mayusculas)
    public static boolean existeNombre(ArrayList<Usuario> usuarios, String nombre) {
        for (Usuario u : usuarios) {
            if (u.getNombreUsuario().equalsIgnoreCase(nombre)) {
                return true;
            }
        }
        return false;
    }

    // Busca un usuario que coincida en nombre Y contrasena.
    // Devuelve el Usuario encontrado o null si no existe.
    public static Usuario buscarUsuario(ArrayList<Usuario> usuarios, String nombre, String contrasena) {
        for (Usuario u : usuarios) {
            if (u.getNombreUsuario().equalsIgnoreCase(nombre) && u.getContrasena().equals(contrasena)) {
                return u;
            }
        }
        return null;
    }
}
