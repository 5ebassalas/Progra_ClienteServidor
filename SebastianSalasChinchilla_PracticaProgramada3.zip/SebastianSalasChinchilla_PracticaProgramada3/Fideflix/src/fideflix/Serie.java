package fideflix;

// Subclase de Audiovisual que representa una serie de television
// (hereda Serializable de Audiovisual)
public class Serie extends Audiovisual implements Comparable<Serie> {

    private static final long serialVersionUID = 1L;

    private int numeroTemporadas; // Cantidad de temporadas de la serie

    public Serie(String titulo, int duracionEnMinutos, String genero, String clasificacionEdad, int numeroTemporadas) {
        super(titulo, duracionEnMinutos, genero, clasificacionEdad); // Llama al constructor de Audiovisual
        this.numeroTemporadas = numeroTemporadas;
    }

    public int getNumeroTemporadas() {
        return numeroTemporadas;
    }

    public void setNumeroTemporadas(int numeroTemporadas) {
        this.numeroTemporadas = numeroTemporadas;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("[Serie] " + getTitulo() + " | Temporadas: " + numeroTemporadas
                + " | " + getDuracionEnMinutos() + " min por episodio | Genero: " + getGenero()
                + " | Clasificacion: " + getClasificacionEdad());
    }

    // Las series se ordenan alfabeticamente por titulo
    @Override
    public int compareTo(Serie otra) {
        return this.getTitulo().compareToIgnoreCase(otra.getTitulo());
    }

    @Override
    public String toString() {
        return getTitulo();
    }
}
