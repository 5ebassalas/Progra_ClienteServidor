package fideflix;

import java.io.Serializable;

// Clase que representa a un usuario de la plataforma Fideflix.
// Implementa Serializable para poder guardar la coleccion de usuarios en un archivo.
public class Usuario implements Comparable<Usuario>, Serializable {

    private static final long serialVersionUID = 1L; // identifica la version de la clase al serializar

    private String nombreUsuario;
    private String correo;
    private String contrasena;

    public Usuario(String nombreUsuario, String correo, String contrasena) {
        this.nombreUsuario = nombreUsuario;
        this.correo = correo;
        this.contrasena = contrasena;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    // Metodo estatico que simula el inicio de sesion e imprime un saludo
    public static void iniciarSesion(Usuario usuario) {
        System.out.println("¡Bienvenido " + usuario.getNombreUsuario() + "!");
    }

    // Los usuarios se ordenan alfabeticamente por nombre de usuario
    @Override
    public int compareTo(Usuario otro) {
        return this.nombreUsuario.compareToIgnoreCase(otro.nombreUsuario);
    }

    // equals y hashCode usan el mismo criterio que compareTo (el nombre de usuario).
    // Asi ArrayList.remove(usuario) encuentra al usuario aunque sea otro objeto
    // con el mismo nombre, y no solo la misma referencia.
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Usuario)) {
            return false;
        }
        Usuario otro = (Usuario) obj;
        return this.nombreUsuario.equalsIgnoreCase(otro.nombreUsuario);
    }

    @Override
    public int hashCode() {
        return nombreUsuario.toLowerCase().hashCode();
    }

    // No se incluye la contrasena para no mostrarla en consola
    @Override
    public String toString() {
        return nombreUsuario + " (" + correo + ")";
    }
}
