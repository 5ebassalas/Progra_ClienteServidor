package fideflix;

// Subclase de Audiovisual que representa una pelicula
// (hereda Serializable de Audiovisual)
public class Pelicula extends Audiovisual implements Comparable<Pelicula> {

    private static final long serialVersionUID = 1L;

    private String director; // Atributo propio de Pelicula

    public Pelicula(String titulo, int duracionEnMinutos, String genero, String clasificacionEdad, String director) {
        super(titulo, duracionEnMinutos, genero, clasificacionEdad); // Llama al constructor de Audiovisual
        this.director = director;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println("[Pelicula] " + getTitulo() + " | Director: " + director
                + " | " + getDuracionEnMinutos() + " min | Genero: " + getGenero()
                + " | Clasificacion: " + getClasificacionEdad());
    }

    // Las peliculas se ordenan alfabeticamente por titulo
    @Override
    public int compareTo(Pelicula otra) {
        return this.getTitulo().compareToIgnoreCase(otra.getTitulo());
    }

    @Override
    public String toString() {
        return getTitulo();
    }
}
