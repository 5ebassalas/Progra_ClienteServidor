package fideflix;

import javax.swing.SwingUtilities;

// Clase principal: solo arranca la aplicacion mostrando la ventana de inicio de sesion.
public class Main {

    public static void main(String[] args) {
        // Las ventanas Swing se crean en el hilo de eventos (EDT), como recomienda Java
        SwingUtilities.invokeLater(() -> new VentanaInicioSesion().setVisible(true));
    }
}
