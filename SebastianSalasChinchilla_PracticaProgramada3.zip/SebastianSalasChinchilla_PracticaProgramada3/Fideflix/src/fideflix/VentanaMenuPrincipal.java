package fideflix;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

// Ventana que se abre despues de un inicio de sesion exitoso.
public class VentanaMenuPrincipal extends JFrame {

    private static final long serialVersionUID = 1L; // JFrame es Serializable; evita la advertencia

    public VentanaMenuPrincipal(Usuario usuario) {
        super("Fideflix - Menú principal");

        // Mensaje de bienvenida con el nombre del usuario que inicio sesion
        JLabel lblBienvenida = new JLabel("Bienvenido " + usuario.getNombreUsuario(), SwingConstants.CENTER);
        lblBienvenida.setFont(new Font("SansSerif", Font.BOLD, 24));

        // Permite volver al inicio de sesion (util para probar otro usuario)
        JButton btnCerrarSesion = new JButton("Cerrar sesión");
        btnCerrarSesion.addActionListener(e -> {
            dispose();
            new VentanaInicioSesion().setVisible(true);
        });

        JPanel panelBoton = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 15));
        panelBoton.add(btnCerrarSesion);

        setLayout(new BorderLayout());
        add(lblBienvenida, BorderLayout.CENTER);
        add(panelBoton, BorderLayout.SOUTH);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(450, 250);
        setLocationRelativeTo(null);
    }
}
