package fideflix;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

// Ventana de inicio de sesion: es la primera que ve el usuario.
public class VentanaInicioSesion extends JFrame {

    private static final long serialVersionUID = 1L; // JFrame es Serializable; evita la advertencia

    private JTextField txtUsuario;
    private JPasswordField txtContrasena;

    public VentanaInicioSesion() {
        super("Fideflix - Inicio de sesión");
        construirInterfaz();

        setDefaultCloseOperation(EXIT_ON_CLOSE); // cerrar esta ventana termina el programa
        setSize(400, 250);
        setResizable(false);
        setLocationRelativeTo(null); // centra la ventana en la pantalla
    }

    // Crea y acomoda los componentes de la ventana
    private void construirInterfaz() {
        JLabel lblTitulo = new JLabel("FIDEFLIX", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 26));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 0, 5, 0));

        txtUsuario = new JTextField();
        txtContrasena = new JPasswordField(); // oculta lo que se escribe

        // Panel central: 2 filas x 2 columnas (etiqueta + campo)
        JPanel panelCampos = new JPanel(new GridLayout(2, 2, 10, 15));
        panelCampos.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        panelCampos.add(new JLabel("Usuario:"));
        panelCampos.add(txtUsuario);
        panelCampos.add(new JLabel("Contraseña:"));
        panelCampos.add(txtContrasena);

        JButton btnIniciar = new JButton("Iniciar Sesión");
        JButton btnCrear = new JButton("Crear Usuario");
        btnIniciar.addActionListener(e -> iniciarSesion());
        btnCrear.addActionListener(e -> abrirCrearUsuario());

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.add(btnIniciar);
        panelBotones.add(btnCrear);

        getRootPane().setDefaultButton(btnIniciar); // Enter = Iniciar Sesion

        setLayout(new BorderLayout());
        add(lblTitulo, BorderLayout.NORTH);
        add(panelCampos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    // Lee la coleccion del archivo y busca si el usuario y la contrasena existen
    private void iniciarSesion() {
        String nombre = txtUsuario.getText().trim();
        String contrasena = new String(txtContrasena.getPassword());

        if (nombre.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Ingrese su usuario y contraseña.",
                    "Campos vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            ArrayList<Usuario> usuarios = GestorUsuarios.cargarUsuarios();
            Usuario encontrado = GestorUsuarios.buscarUsuario(usuarios, nombre, contrasena);

            if (encontrado == null) {
                // No existe (o la contrasena no coincide): sin acceso
                JOptionPane.showMessageDialog(this, "El usuario no tiene acceso a la aplicación.",
                        "Acceso denegado", JOptionPane.ERROR_MESSAGE);
                txtContrasena.setText("");
            } else {
                // Existe: se abre el menu principal y se cierra esta ventana
                new VentanaMenuPrincipal(encontrado).setVisible(true);
                dispose();
            }
        } catch (IOException | ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo leer el archivo de usuarios:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Oculta esta ventana y abre la de crear usuario (que la vuelve a mostrar al cerrarse)
    private void abrirCrearUsuario() {
        new VentanaCrearUsuario(this).setVisible(true);
        setVisible(false);
    }
}
