package fideflix;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

// Ventana que permite crear usuarios uno a uno y guardarlos en el archivo.
public class VentanaCrearUsuario extends JFrame {

    private static final long serialVersionUID = 1L; // JFrame es Serializable; evita la advertencia

    private JTextField txtUsuario;
    private JTextField txtCorreo;
    private JPasswordField txtContrasena;

    public VentanaCrearUsuario(final VentanaInicioSesion ventanaLogin) {
        super("Fideflix - Crear usuario");
        construirInterfaz();

        // Al cerrar esta ventana (con la X o con "Volver") se vuelve a mostrar el inicio de sesion
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                ventanaLogin.setVisible(true);
            }
        });

        setSize(400, 300);
        setResizable(false);
        setLocationRelativeTo(null); // centra la ventana en la pantalla
    }

    // Crea y acomoda los componentes de la ventana
    private void construirInterfaz() {
        JLabel lblTitulo = new JLabel("Crear nuevo usuario", SwingConstants.CENTER);
        lblTitulo.setFont(new Font("SansSerif", Font.BOLD, 18));
        lblTitulo.setBorder(BorderFactory.createEmptyBorder(15, 0, 5, 0));

        txtUsuario = new JTextField();
        txtCorreo = new JTextField();
        txtContrasena = new JPasswordField();

        // Panel central: 3 filas x 2 columnas (etiqueta + campo)
        JPanel panelCampos = new JPanel(new GridLayout(3, 2, 10, 15));
        panelCampos.setBorder(BorderFactory.createEmptyBorder(15, 30, 15, 30));
        panelCampos.add(new JLabel("Usuario:"));
        panelCampos.add(txtUsuario);
        panelCampos.add(new JLabel("Correo:"));
        panelCampos.add(txtCorreo);
        panelCampos.add(new JLabel("Contraseña:"));
        panelCampos.add(txtContrasena);

        JButton btnGuardar = new JButton("Guardar");
        JButton btnVolver = new JButton("Volver");
        btnGuardar.addActionListener(e -> guardarUsuario());
        btnVolver.addActionListener(e -> dispose()); // dispose() dispara windowClosed

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panelBotones.add(btnGuardar);
        panelBotones.add(btnVolver);

        getRootPane().setDefaultButton(btnGuardar); // Enter = Guardar

        setLayout(new BorderLayout());
        add(lblTitulo, BorderLayout.NORTH);
        add(panelCampos, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
    }

    // Valida los datos, agrega el usuario a la coleccion y la guarda en el archivo
    private void guardarUsuario() {
        String nombre = txtUsuario.getText().trim();
        String correo = txtCorreo.getText().trim();
        String contrasena = new String(txtContrasena.getPassword());

        // Validacion de campos vacios
        if (nombre.isEmpty() || correo.isEmpty() || contrasena.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios.",
                    "Campos vacíos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            // 1. Leer la coleccion actual (vacia si el archivo no existe)
            ArrayList<Usuario> usuarios = GestorUsuarios.cargarUsuarios();

            // 2. Validacion de usuario duplicado
            if (GestorUsuarios.existeNombre(usuarios, nombre)) {
                JOptionPane.showMessageDialog(this, "El usuario '" + nombre + "' ya existe.",
                        "Usuario duplicado", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // 3. Agregar el nuevo usuario y guardar toda la coleccion
            usuarios.add(new Usuario(nombre, correo, contrasena));
            GestorUsuarios.guardarUsuarios(usuarios);

            JOptionPane.showMessageDialog(this, "Usuario guardado correctamente.",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
            limpiarCampos(); // queda listo para crear otro usuario

        } catch (IOException | ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo leer o guardar el archivo de usuarios:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void limpiarCampos() {
        txtUsuario.setText("");
        txtCorreo.setText("");
        txtContrasena.setText("");
        txtUsuario.requestFocus();
    }
}
