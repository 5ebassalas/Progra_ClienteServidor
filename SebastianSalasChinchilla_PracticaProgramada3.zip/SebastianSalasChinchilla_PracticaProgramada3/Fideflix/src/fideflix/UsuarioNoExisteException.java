package fideflix;

// Excepcion propia que se lanza cuando se intenta eliminar un usuario
// que no esta en la coleccion. Extiende Exception, por lo que es "checked":
// el compilador obliga a manejarla con try/catch o a declararla con throws.
public class UsuarioNoExisteException extends Exception {

    private static final long serialVersionUID = 1L; // evita la advertencia del compilador

    public UsuarioNoExisteException(String mensaje) {
        super(mensaje);
    }
}
