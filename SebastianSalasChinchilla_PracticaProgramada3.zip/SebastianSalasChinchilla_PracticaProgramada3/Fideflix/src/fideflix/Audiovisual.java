package fideflix;

import java.io.Serializable;
import java.util.ArrayList;

// Clase padre abstracta: no tiene sentido crear un "Audiovisual" generico,
// solo peliculas, series o documentales, por eso no se puede instanciar.
// Implementa Serializable para que sus subclases tambien se puedan guardar en un archivo.
public abstract class Audiovisual implements Serializable {

    private static final long serialVersionUID = 1L; // identifica la version de la clase al serializar

    private String titulo;
    private int duracionEnMinutos;
    private String genero;
    private String clasificacionEdad;

    // Es static porque el metodo agregarComentario tambien es static, y un metodo
    // estatico solo puede usar atributos estaticos. Asi todos los comentarios
    // quedan en una sola coleccion compartida por todo el contenido.
    // Los atributos static NO se serializan (pertenecen a la clase, no al objeto).
    private static ArrayList<String> comentarios = new ArrayList<>();

    public Audiovisual(String titulo, int duracionEnMinutos, String genero, String clasificacionEdad) {
        this.titulo = titulo;
        this.duracionEnMinutos = duracionEnMinutos;
        this.genero = genero;
        this.clasificacionEdad = clasificacionEdad;
    }

    // Metodo abstracto: cada subclase lo sobrescribe a su manera (polimorfismo)
    public abstract void mostrarInformacion();

    // Metodo estatico que guarda un comentario de un usuario en la coleccion
    public static void agregarComentario(String comentario) {
        comentarios.add(comentario);
    }

    public static ArrayList<String> getComentarios() {
        return comentarios;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getDuracionEnMinutos() {
        return duracionEnMinutos;
    }

    public void setDuracionEnMinutos(int duracionEnMinutos) {
        this.duracionEnMinutos = duracionEnMinutos;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getClasificacionEdad() {
        return clasificacionEdad;
    }

    public void setClasificacionEdad(String clasificacionEdad) {
        this.clasificacionEdad = clasificacionEdad;
    }
}
